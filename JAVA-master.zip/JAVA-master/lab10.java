import shape.*;

public class lab10
{
  public static void main(String[] args)
  {
    System.out.print(circle.area(3)+"\n");
    System.out.print(circle.perimeter(3)+"\n");
    System.out.print(rectangle.area1(6)+"\n");
    System.out.print(rectangle.perimeter1(6)+"\n");
    System.out.print(square.area2(4)+"\n");
    System.out.print(square.perimeter2(4)+"\n");
  }
}
