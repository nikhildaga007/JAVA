package shape;


public class square
{
  public static double area2(double a)
  {

    return a*a;

  }
  public static double perimeter2(double b)
  {

    return 4*b;

  }
}
