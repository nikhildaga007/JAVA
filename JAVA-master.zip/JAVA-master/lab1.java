import java.lang.*;

class lab1
{
	public static void main(String args[])
	{
		System.out.print("AMITY");
	}
}
