import java.awt.*;
import java.lang.*;

class test extends Frame
{
	test()
	{	
		setTitle("BCA5");
		setSize(400,400);
		setBackground(Color.black);
		setVisible(true);

	}
}

class lab17
{
	public static void main (String[] args)
	{
		test obj= new test();
	}
}