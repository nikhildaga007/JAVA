  package mypack;

public class test
{
  public static int intAdd(int a, int b)
  {
    return a+b;
  }
}
