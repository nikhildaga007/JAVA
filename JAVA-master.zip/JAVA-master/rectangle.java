package shape;


  public class rectangle
  {
    public static double area1(double a, double b)
    {

      return double a*b;

    }
    public static double perimeter1(double c,double d)
    {

      return double 2*(c+d);

    }
}
