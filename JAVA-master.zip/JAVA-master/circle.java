package shape;
import java.lang.Math;

public class circle
{
  public static double area(double a)
  {

    return Math.PI*a*a;

  }
  public static double perimeter(double b)
  {

    return 2*(Math.PI*b);

  }
}
