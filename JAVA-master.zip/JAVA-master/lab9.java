import mypack.*;

public class lab9
{
  public static void main(String[] args)
  {
    System.out.print(test.intAdd(2,1));
  }
}
